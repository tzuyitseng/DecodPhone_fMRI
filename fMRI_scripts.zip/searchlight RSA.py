import os
import numpy as np
import pandas as pd
import nibabel as nib
import seaborn as sns
import matplotlib.pyplot as plt
from glob import glob
from nilearn.maskers import NiftiMasker
from rsatoolbox.inference import eval_fixed
from rsatoolbox.model import ModelFixed
from rsatoolbox.rdm import RDMs
from rsatoolbox.util.searchlight import get_volume_searchlight, get_searchlight_RDMs, evaluate_models_searchlight
from scipy.stats import spearmanr
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.multicomp import pairwise_tukeyhsd

import warnings
from nilearn import image, maskers, plotting, datasets, masking
from nilearn.image import new_img_like, threshold_img, math_img, load_img, resample_to_img, coord_transform, mean_img, get_data, index_img
from nilearn.plotting import view_img, plot_stat_map, plot_glass_brain, plot_img, plot_design_matrix
from nilearn.glm.thresholding import threshold_stats_img
from nilearn.reporting import get_clusters_table
from nilearn.glm.second_level import SecondLevelModel, non_parametric_inference


data_path = ''
sub_list = ['']

mask_path = ''
tmap_path = ''
save_dir = ''
rho_path = ''

conditions = ['intFRlabial', 'intFRdental', 'intFRffricative', 'intFRbfricative',
              'noiFRlabial', 'noiFRdental', 'noiFRffricative', 'noiFRbfricative',
              'intCHlabial', 'intCHdental', 'intCHffricative', 'intCHbfricative',
              'noiCHlabial', 'noiCHdental', 'noiCHffricative', 'noiCHbfricative']

masks = ['PreCG','PoCG','IFG','INS','SMG','STG','MTG']
models = ['place','manner','aspiration_plo','voicing_fri']


### searchlight RSA

all_eval_scores = {}

for ml in models:
    eval_scores_per_subject = []
    print(f'====={ml}=====')

    for subject in sub_list:
        mask_img = nib.load(data_path + 'mvpa/searchlight/7ROIs_mask.nii.gz')
        mask = mask_img.get_fdata() > 0
        x, y, z = mask_img.get_fdata().shape

        image_paths = []
        for condition in conditions:
            tmap_paths = os.path.join(tmap_path, f'{subject}_task-phono_desc-{condition}-BL_stat.nii.gz')
            image_paths.append(tmap_paths)
        print(subject, len(image_paths))

        data = np.zeros((len(image_paths), x, y, z))
        for x, im in enumerate(image_paths):
            data[x] = nib.load(im).get_fdata()

        centers, neighbors = get_volume_searchlight(mask, radius=4, threshold=0.5)  # 10mm radius in voxel units

        data_2d = data.reshape([data.shape[0], -1])
        data_2d = np.nan_to_num(data_2d)
        image_value = np.arange(len(image_paths))
        neural_rdms = get_searchlight_RDMs(data_2d, centers, neighbors, image_value, method='correlation')

        concept_rdm_array = pd.read_csv(os.path.join(save_dir, 'conceptualRDMs', 'phono_feature', f'{ml}.csv'), index_col=0).values
        concept_rdm_vector = concept_rdm_array[np.triu_indices_from(concept_rdm_array, k=1)]
        concept_rdm_array = np.array([concept_rdm_vector])
        concept_rdm = RDMs(dissimilarities=concept_rdm_array, descriptors={'conditions': conditions})
        model = ModelFixed('Conceptual Model', concept_rdm)

        eval_results = evaluate_models_searchlight(neural_rdms, model, eval_fixed, method='spearman')
        eval_score = [float(e.evaluations) for e in eval_results]

        # Store the eval_score for this subject
        eval_scores_per_subject.append(eval_score)

        # Create a 3D array, with the size of the mask
        x, y, z = mask.shape
        RDM_brain = np.zeros([x * y * z])
        RDM_brain[list(neural_rdms.rdm_descriptors['voxel_index'])] = eval_score
        RDM_brain = RDM_brain.reshape([x, y, z])

        subject_rsa_img = new_img_like(mask_img, RDM_brain)
        result_path = os.path.join(save_dir, 'searchlightRSA_all_lang', f'{subject}_seachlightRSA_all_{ml}.nii.gz')
        nib.save(subject_rsa_img, result_path)

    all_eval_scores[ml] = eval_scores_per_subject

# Save the eval scores as CSV
for ml, scores in all_eval_scores.items():
    df = pd.DataFrame(scores, index=sub_list)
    csv_path = os.path.join(save_dir, 'searchlightRSA_all_lang', 'eval_scores', f'{ml}_eval_scores.csv')
    df.to_csv(csv_path)



### permutation test


import matplotlib.colors
def RDMcolormapObject(direction=1):
    """
    Returns a matplotlib color map object for RSA and brain plotting
    """
    if direction == 0:
        cs = ['yellow', 'red', 'gray', 'turquoise', 'blue']
    elif direction == 1:
        cs = ['blue', 'turquoise', 'gray', 'red', 'yellow']
    else:
        raise ValueError('Direction needs to be 0 or 1')
    cmap = matplotlib.colors.LinearSegmentedColormap.from_list("", cs)
    return cmap


import os
import warnings
import numpy as np
import nibabel as nib
import pandas as pd
import matplotlib.pyplot as plt
from nilearn import image, maskers, plotting, datasets, masking
from nilearn.image import threshold_img, math_img, load_img, resample_to_img, coord_transform, mean_img, get_data, index_img
from nilearn.plotting import view_img, plot_stat_map, plot_glass_brain, plot_img, plot_design_matrix
from nilearn.glm.thresholding import threshold_stats_img
from nilearn.reporting import get_clusters_table
from nilearn.glm.second_level import SecondLevelModel, non_parametric_inference


mask_img = nib.load('')

for ml in models:
    print(ml)
    imgs = []
    for i, subject in enumerate(sub_list):
        img_sub = os.path.join(data_path, f'{subject}_seachlightRSA_all_{ml}.nii.gz')
        #h0_map = math_img('img - 0.5', img=img_sub)
        imgs.append(img_sub)

    second_level_input = imgs
    design_matrix = pd.DataFrame(
        [1] * len(second_level_input),
        columns=["intercept"],
    )
    
    ## permutation test
    out_dict_voxel = non_parametric_inference(
        second_level_input,
        design_matrix=design_matrix,
        model_intercept=True,
        mask=mask_img,
        n_perm=10000,
        two_sided_test=True,
        n_jobs=-1,
        threshold=0.05
    )

    result_img = out_dict_voxel['t']
    result_path = os.path.join(data_path, f'perm_seachlightRSA_all_{ml}.nii.gz')
    nib.save(result_img, result_path)
    result_img_FWE = out_dict_voxel['logp_max_t']
    result_path_FWE = os.path.join(data_path, f'perm_seachlightRSA_all_FWE_{ml}.nii.gz')
    nib.save(result_img_FWE, result_path_FWE)
    
    cmap = RDMcolormapObject()
    mean_correlation_img = mean_img(imgs)
    plot_glass_brain(
        mean_correlation_img,
        display_mode='lyrz',
        vmin=-1,
        cmap=cmap,
        colorbar=True,
        title=f"seachlight RSA_all_{ml}",
        figure=plt.figure(figsize=(8, 3))
    )
    plt.show()

#plot

for ml in models:
    img_searchlight = os.path.join(data_path, f'perm_seachlightRSA_all_{ml}.nii.gz')
    result_img001, threshold001 = threshold_stats_img(img_searchlight, alpha=0.05, threshold=None, height_control='fpr', cluster_threshold=60, two_sided=False)
    cmap=RDMcolormapObject()
    plot_glass_brain(
        result_img001, 
        colorbar=True,
        plot_abs=False,
        #cmap=cmap,
        #cmap='Spectral_r',
        #vmax=6.1,
        threshold=threshold001,
        display_mode='lzry',
        #title=f"{ml} (FDR p<0.05, cluster > 40 voxels)",
        figure=plt.figure(figsize=(8, 3))
    )
    
    #create mask 
    binary_mask = math_img('(np.abs(img) > 0)', img=result_img001)
    result_path = os.path.join(rho_path, f'seachlightRSA_all_mask_{ml}.nii.gz')
    plot_glass_brain(binary_mask, display_mode='lzry',figure=plt.figure(figsize=(8, 3)))
    nib.save(binary_mask, result_path)
    plt.show()


import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from nilearn.image import load_img, math_img
from nilearn.plotting import plot_stat_map
from nilearn.glm import threshold_stats_img


# Load and threshold all images
results = {}
thresholds = {}
for model in models:
    img_path = os.path.join(data_path, f'perm_seachlightRSA_all_{model}.nii.gz')
    result_img, threshold = threshold_stats_img(
        img_path,
        alpha=0.05,
        threshold=None,
        height_control='fpr',
        cluster_threshold=40,
        two_sided=False
    )
    results[model] = result_img
    thresholds[model] = threshold

# Invert "manner" for contrast
results['manner'] = math_img("img * -1", img=results['manner'])

# Slice coordinates between -40 and 40
#x_slices = np.linspace(-60, 60, 6)
x_slices = [-60, -50, -40, 40, 50, 60]

# Set up figure with 2 rows × 3 columns
fig, axes = plt.subplots(2, 3, figsize=(18, 10))
axes = axes.ravel()

# Define colormaps
cmaps = {
    'place': plt.cm.autumn,
    'manner': plt.cm.summer_r,
    'voicing_fri': mcolors.ListedColormap(plt.get_cmap('Purples')(np.linspace(0.7, 1.0, 256))),
    'aspiration_plo': mcolors.ListedColormap(plt.get_cmap('Reds')(np.linspace(0.7, 1.0, 256)))
}

# Plot overlays at each x-slice
for i, x in enumerate(x_slices):
    # Base plot with 'place'
    display = plot_stat_map(
        results['place'],
        display_mode='x',
        cut_coords=[x],
        threshold=thresholds['place'],
        cmap=cmaps['place'],
        colorbar=False,
        axes=axes[i],
        figure=fig,
        #title=f"x = {x:.0f}"
    )

    # Overlay others
    display.add_overlay(results['manner'], cmap=cmaps['manner'], threshold=thresholds['manner'])
    display.add_overlay(results['aspiration_plo'], cmap=cmaps['aspiration_plo'], threshold=thresholds['aspiration_plo'])
    display.add_overlay(results['voicing_fri'], cmap=cmaps['voicing_fri'], threshold=thresholds['voicing_fri'])

    # Add binary ROI mask (transparent)
    display.add_overlay(roi_img, cmap=plt.cm.gray, alpha=0.07)

# Tidy layout
plt.tight_layout()
plt.show()




