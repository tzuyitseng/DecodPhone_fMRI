#!/usr/bin/env python
# coding: utf-8

import os
import nibabel as nib
import numpy as np
import csv
from nilearn.decoding import Decoder
from nilearn.image import load_img, mean_img, math_img
from sklearn.metrics import accuracy_score
from sklearn.model_selection import LeaveOneGroupOut
import warnings
warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
from nilearn.plotting import view_img

def load_apply_mask_and_demean(subject, conditions, groups, path, task_name, mask_img, demean_path):
    img_paths = []
    masked_images = []
    demeaned_images = []
    group_masked = {group: [] for group in groups}
    
    for condition in conditions:
        for group in groups:
            img_path = os.path.join(path, f'sub-{subject}', f'sub-{subject}_task-{task_name}_desc-{condition}-{group}_stat.nii.gz')
            img_paths.append(img_path)
            img = load_img(img_path)
            masked_img = math_img('img * mask', img=img, mask=mask_img)
            masked_images.append(masked_img)
            group_masked[group].append(masked_img)

    mean_img_group = {group: mean_img(group_masked[group]) for group in groups}
    
    for idx, masked_img in enumerate(masked_images):
        group_index = idx % len(groups)
        group = groups[group_index]
        mean_image = mean_img_group[group]
        demeaned_img = math_img('img - mean_image', img=masked_img, mean_image=mean_image) # normalize the difference between two modalities
        demeaned_images.append(demeaned_img)
        
        demeaned_path = os.path.join(demean_path, f'sub-{subject}_task-{task_name}_desc-{conditions[idx // len(groups)]}-{group}_demeaned.nii.gz')
        nib.save(demeaned_img, demeaned_path)

    return img_paths, mean_img_group, demeaned_images

def load_demeaned_images(subject, condition, groups, path, task_name):
    images = []
    labels = []
    for group in groups:
        img_path = os.path.join(path, f'sub-{subject}_task-{task_name}_desc-{condition}-{group}_demeaned.nii.gz')
        images.append(img_path)
        labels.append(condition)
    return images, labels

# Paths
ROI = 'MNI-LTF-FWE01-ROI10' ## change mask pattern manually
mvpa_path = ''
data_path = ''
mask_path = ''
csv_path = ''
motor_path = ''
percep_path = ''
motor_demean = ''
percep_demean = ''
sub_list = ['']

# Loop over hemispheres
for selected_hemisphere in ['RH', 'LH']:
    # Update the mask pattern based on the selected hemisphere
    mask_pattern = '{}_MNI-LTF-FWE01-ROI10_{}.nii.gz'.format('{}', selected_hemisphere)
    print('*' * 100)
    print('[', selected_hemisphere, ']')
    print('*' * 100)

    # Define the pairs of perception conditions to test
    test_conditions_percep_pairs = [
        ['21-labial-BL', '22-dental-BL'],
        ['83-intact-labial-BL', '84-intact-dental-BL'],
        ['85-noisy-labial-BL', '86-noisy-dental-BL'],
        ['27-intact-FR-labial-BL', '31-intact-FR-dental-BL'],
        ['29-intact-CH-labial-BL', '33-intact-CH-dental-BL'],
        ['28-noisy-FR-labial-BL', '32-noisy-FR-dental-BL'],
        ['30-noisy-CH-labial-BL', '34-noisy-CH-dental-BL'],
        ['25-bilabial-dental', '26-dental-bilabial'],
        ['35-intact-FR-labial-dental', '39-intact-FR-dental-labial'],
        ['36-intact-CH-labial-dental', '40-intact-CH-dental-labial'],
        ['38-noisy-FR-labial-dental', '42-noisy-FR-dental-labial'],
        ['37-noisy-CH-labial-dental', '41-noisy-CH-dental-labial'],
    ]
    
    # Define the header for the CSV file to include accuracy for each pair of conditions
    #header = ['subject', 'folds', 'voxel_size', 'motor_acc'] + [f'percep_acc_pair{i+1}' for i in range(len(test_conditions_percep_pairs))]
    header = ['subject', 'folds', 'voxel_size', 'motor_acc', 'percep_acc_all', 'percep_acc_int', 'percep_acc_noi', 'percep_acc_intFR', 'percep_acc_intCH', 'percep_acc_noiFR', 'percep_acc_noiCH', 'percep_acc_all_c', 'percep_acc_intFR_c', 'percep_acc_intCH_c', 'percep_acc_noiFR_c', 'percep_acc_noiCH_c']
    csv_file = os.path.join(csv_path, f'MPclassif_dem_{ROI}_{selected_hemisphere}.csv')
    with open(csv_file, mode='w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(header)

        # Loop over subjects
        for subject in sub_list:
            mask_img = load_img(os.path.join(mask_path, mask_pattern.format(subject)))

            # Define motor conditions
            all_train_images_motor = []
            all_train_labels_motor = []
            all_train_groups_motor = []
            train_conditions_motor = ['Lip-BL', 'Tongue-BL']
            img_paths_motor, mean_img_group_motor, demeaned_images_motor = load_apply_mask_and_demean(subject, train_conditions_motor, np.arange(1, 7), motor_path, 'loc', mask_img, motor_demean)

            # Load and process motor conditions
            for condition in train_conditions_motor:
                images_motor, labels_motor = load_demeaned_images(subject, condition, np.arange(1, 7), motor_demean, 'loc')
                all_train_images_motor.extend(images_motor)
                all_train_labels_motor.extend(['Lips' if label == 'Lip-BL' else 'Tongue' for label in labels_motor])
                all_train_groups_motor.extend([f'Group-{i}' for i in np.arange(1, 7)])

            all_accuracy_fold_percep_pair = [] 
            avg_accuracy_fold_motor = []
            # Loop over perception condition pairs
            for pair_idx, perception_pair in enumerate(test_conditions_percep_pairs):
                test_conditions_percep = perception_pair
                img_paths_percep, mean_img_group_percep, demeaned_images_percep = load_apply_mask_and_demean(subject, test_conditions_percep, np.arange(1, 7), percep_path, 'phono', mask_img, percep_demean)

                # Load and process perception conditions
                all_test_images_percep = []
                all_test_labels_percep = []
                all_test_groups_percep = []
                for condition in perception_pair:
                    images_percep, labels_percep = load_demeaned_images(subject, condition, np.arange(1, 7), percep_demean, 'phono')
                    all_test_images_percep.extend(images_percep)
                    all_test_labels_percep.extend(['Lips' if 'labial' in label else 'Tongue' for label in labels_percep])
                    all_test_groups_percep.extend([f'Group-{i}' for i in np.arange(1, 7)])

                # Decoder object for motor
                cv_motor = LeaveOneGroupOut()
                decoder_motor = Decoder(estimator='svc', mask=mask_img, cv=cv_motor, screening_percentile = 20, standardize="zscore_sample", scoring="accuracy")

                all_accuracy_fold_motor = []
                all_accuracy_fold_percep = []
                folds = []
                # Perform cross-validation for motor
                for fold_motor, (train_idx_motor, test_idx_motor) in enumerate(cv_motor.split(all_train_images_motor, all_train_labels_motor, groups=all_train_groups_motor), 1):
                    X_train_motor, X_test_motor = np.array(all_train_images_motor)[train_idx_motor], np.array(all_train_images_motor)[test_idx_motor]
                    y_train_motor, y_test_motor = np.array(all_train_labels_motor)[train_idx_motor], np.array(all_train_labels_motor)[test_idx_motor]
                    folds.append(fold_motor)
                    train_groups_motor = np.array(all_train_groups_motor)[train_idx_motor]

                    decoder_motor.fit(X_train_motor, y_train_motor, groups=train_groups_motor)
                    coef_shapes = decoder_motor.coef_.shape[1]
                    y_pred_motor = decoder_motor.predict(X_test_motor)
                    y_true_motor = y_test_motor
                    accuracy_fold_motor = accuracy_score(y_true_motor, y_pred_motor)
                    all_accuracy_fold_motor.append(accuracy_fold_motor)
                    print(f'decoding: {subject} {selected_hemisphere} fold: {fold_motor}')
                    print(f'X_test_motor:{X_test_motor}')
                    print(f'y_test_motor:{y_test_motor}')
                    print(f'y_true_motor:{y_true_motor}')
                    print(f'y_pred_motor:{y_pred_motor}')
                    print(f'accuracy_fold_motor:{accuracy_fold_motor}','\n')

                    # Test on perception images using the same motor decoder
                    y_pred_percep = decoder_motor.predict(all_test_images_percep)
                    y_true_percep = all_test_labels_percep
                    accuracy_fold_percep = accuracy_score(y_true_percep, y_pred_percep)
                    all_accuracy_fold_percep.append(accuracy_fold_percep)
                    print(f'decoding percep: {test_conditions_percep}')
                    print(f'images_percep: {all_test_images_percep[0]} {all_test_images_percep[6]}')
                    print(f'labels_percep: {all_test_labels_percep}')
                    print(f'y_true_percep: {y_true_percep}')
                    print(f'y_pred_percep: {y_pred_percep}')
                    print(f'accuracy_fold_percep: {accuracy_fold_percep}')
                    print('-' * 50)

                avg_accuracy_fold_percep = np.mean(all_accuracy_fold_percep)
                all_accuracy_fold_percep_pair.append(all_accuracy_fold_percep)               
                avg_accuracy_fold_motor = np.mean(all_accuracy_fold_motor)
                print(f'avg_accuracy: {subject} motor: {avg_accuracy_fold_motor}; perception: {test_conditions_percep} {avg_accuracy_fold_percep}')
                print('=' * 50,'\n')

            header = ['subject', 'folds', 'coef_shapes', 'motor_acc'] + [f'percep_acc_pair_{i+1}' for i in range(len(all_accuracy_fold_percep_pair))]
            coef_repeated = [coef_shapes] * len(folds)
            subject_repeated = [subject] * len(folds)
            transposed_percep_pair = list(zip(*all_accuracy_fold_percep_pair))
            percep_pair_cols = [list(col) for col in zip(*transposed_percep_pair)]
            combined_data = [subject_repeated, folds, coef_repeated, all_accuracy_fold_motor] + percep_pair_cols
            transposed_data = list(zip(*combined_data))
            for row in transposed_data:
                writer.writerow(row)

print(decoder_motor.coef_)
decoder_motor.get_params()