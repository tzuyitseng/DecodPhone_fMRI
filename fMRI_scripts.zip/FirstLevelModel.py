#!/usr/bin/env python
# coding: utf-8

# ======================================================================
# IMPORT RELEVANT PACKAGES
# ======================================================================
import os
import re
import sys
import pandas as pd
import numpy as np
from bids.layout import BIDSLayout
from nilearn.glm.first_level import FirstLevelModel, make_first_level_design_matrix
import joblib
import matplotlib.pyplot as plt
from nilearn.plotting import plot_design_matrix
# ======================================================================
pwd = ''
data_path = ''
code_path = ''
dm_path = data_path + 'results/FirstLevel/design_matrices/'
sub_to_exclude = ''
layout = BIDSLayout(data_path, derivatives=True, ignore=[re.compile(r'(sub-(?=sub_to_exclude))')])
subjects = layout.get_subjects()
# ======================================================================
for sID in subjects:
    print(sID)
    anat = layout.get(subject=sID, datatype='anat', space='MNI152NLin2009cAsym', desc='preproc', extension='.nii.gz', return_type='filename')
    bold = layout.get(subject=sID, datatype='func', task='phono', space='MNI152NLin2009cAsym', desc='preproc', extension='.nii.gz', return_type='filename')
    events = layout.get(subject=sID, datatype='func', task='phono', suffix='events', extension=".tsv", return_type='filename')
    confounds = layout.get(subject=sID, datatype='func', task='phono', desc='confounds', extension=".tsv", return_type='filename')

    confounds_of_interest = [
        'trans_x', 'trans_x_derivative1', 'trans_x_derivative1_power2', 'trans_x_power2', 'trans_y', 'trans_y_derivative1', 'trans_y_derivative1_power2', 'trans_y_power2', 'trans_z', 'trans_z_derivative1', 'trans_z_derivative1_power2', 'trans_z_power2', 
        'rot_x', 'rot_x_derivative1', 'rot_x_power2', 'rot_x_derivative1_power2', 'rot_y', 'rot_y_derivative1', 'rot_y_derivative1_power2', 'rot_y_power2', 'rot_z', 'rot_z_derivative1', 'rot_z_power2', 'rot_z_derivative1_power2', 
        'c_comp_cor_00', 'c_comp_cor_01', 'c_comp_cor_02', 'c_comp_cor_03', 'c_comp_cor_04', 
        'w_comp_cor_00', 'w_comp_cor_01', 'w_comp_cor_02', 'w_comp_cor_03', 'w_comp_cor_04'
    ] 

    # Get the TR
    TR = layout.get_tr()

    # Create the design matrices
    design_matrices = []
    for bold_file, event_file, confound_file in zip(bold, events, confounds):
        this_event = pd.read_table(event_file)
        this_event.rename(columns={'accuracy': 'modulation'}, inplace=True)
        this_event.loc[(this_event['trial_type'] == 'BL') | (this_event['trial_type'] == 'NI'), 'modulation'] = 1
        this_event.fillna(0, inplace=True)

        this_conf = pd.read_table(confound_file)
        this_conf = this_conf[confounds_of_interest].fillna(0)

        # Get the number of volumes (time frames) from the BOLD file
        n_volumes = this_conf.shape[0]
        frame_times = np.arange(n_volumes) * TR

        design_matrix = make_first_level_design_matrix(frame_times, this_event, add_regs=this_conf, hrf_model='spm', high_pass=1./128)
        design_matrices.append(design_matrix)
    for i, design_matrix in enumerate(design_matrices):
        plot_design_matrix(design_matrix)
        plt.title(f"{sID} Run {i+1}", loc='left', y=1.15)
        plt.savefig(os.path.join(dm_path , f"{sID}_run{i+1}.png"))
        plt.close()
### fit the GLM model        
    fmri_glm = FirstLevelModel(t_r = TR,
                           noise_model = 'ar1',
                           hrf_model = 'spm',
                           drift_model = 'Cosine',
                           high_pass = 1./128,
                           slice_time_ref = 0.5, 
                           smoothing_fwhm = 6,
                           signal_scaling = False,
                           minimize_memory = False)
    fmri_glm = fmri_glm.fit(bold, design_matrices=design_matrices)

    # Access the design matrices
    fitted_design_matrices = fmri_glm.design_matrices_

    joblib.dump(fmri_glm, os.path.join(code_path, f'flm_glm_{sID}.pkl'))
    joblib.dump(design_matrices, os.path.join(code_path, f'design_matrices_{sID}.pkl'))
print('done')