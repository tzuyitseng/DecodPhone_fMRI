#!/usr/bin/env python
# coding: utf-8

# ======================================================================
import os
import re
import pandas as pd
import numpy as np
import nibabel as nib
from bids.layout import BIDSLayout
from nilearn.glm.second_level import SecondLevelModel
from nilearn.glm import threshold_stats_img
from nilearn.reporting import get_clusters_table
from nilearn import plotting
import matplotlib.pyplot as plt
from nilearn.plotting import plot_design_matrix
from collections import defaultdict
from atlasreader import create_output
# ======================================================================
pwd = ''
data_path = ''
tmap_path = ''
code_path = ''
dm_path = ''
sl_path = ''
subjects = ['']
n_subjects = len(subjects)
# ======================================================================
contrasts = {
    'FR-CH': 'FR-CH',
    'intact-noisy': 'intact-noisy',
    'intFR-intCH': 'intFR-intCH',
    'noiFR-noiCH': 'noiFR-noiCH',
    'intFR-noiFR': 'intFR-noiFR',
    'intCH-noiCH': 'intCH-noiCH',
}

# Step 1: Extract unique values from the contrast keys
unique_values = set()
for key in contrasts.keys():
    parts = key.split('-')
    unique_values.update(parts)

# Step 2: Search for files with the corresponding contrast_id
contrast_files = defaultdict(list)

for filename in os.listdir(tmap_path):
    if filename.endswith('.nii.gz'):
        match = re.search(r'desc-(.+)_stat.nii.gz', filename)
        if match:
            contrast_id = match.group(1)
            if contrast_id in unique_values:
                contrast_files[contrast_id].append(os.path.join(tmap_path, filename))

# Create the design matrices for each contrast pair
for contrast_pair in contrasts.keys():
    contrast_id1, contrast_id2 = contrast_pair.split('-')
    print(f'{contrast_id1}-{contrast_id2}')
    if contrast_id1 in contrast_files and contrast_id2 in contrast_files:
        # Combine the file paths for the second-level input
        second_level_input = contrast_files[contrast_id1] + contrast_files[contrast_id2]
        
        # Create the condition effect and subject effect arrays
        condition_effect = np.hstack(([1] * n_subjects, [-1] * n_subjects))
        subject_effect = np.vstack((np.eye(n_subjects), np.eye(n_subjects)))
        
        # Create the design matrix
        design_matrix = pd.DataFrame(
            np.hstack((condition_effect[:, np.newaxis], subject_effect)),
            columns=[f'{contrast_id1}-{contrast_id2}'] + subjects
        )
        plot_design_matrix(design_matrix)
        plt.savefig(os.path.join(dm_path , f'{contrast_pair}.png'))
        plt.close()
        second_level_model = SecondLevelModel(n_jobs=-1).fit(
            second_level_input, design_matrix=design_matrix
        )
        z_map = second_level_model.compute_contrast(f'{contrast_id1}-{contrast_id2}', output_type='z_score')
        zname = os.path.join(sl_path, f'{contrast_pair}.nii.gz')
        z_map.to_filename(zname)
        
        fpr_map, threshold05 = threshold_stats_img(
            z_map, 
            alpha=0.001,
            height_control='fpr',
            two_sided=True,
            cluster_threshold=5
        )
        
        # Get peaks   
        peaks = get_clusters_table(fpr_map, stat_threshold=threshold05)
        
        # If there is any peak then save the map and generate report
        if len(peaks) != 0:
            print('Creating output for', contrast_pair)
            fname = os.path.join(sl_path, contrast_pair + '_fpr001v5.nii.gz')
            fpr_map.to_filename(fname)
            # Generate and save also atlasreader output
            create_output(
                fname, 
                cluster_extent=5, 
                voxel_thresh=threshold05,
                direction='pos',
                outdir=os.path.join(sl_path, 'atlasreader', contrast_pair)
            )
        else:
            print('No significant voxels at fpr001 for', contrast_pair)
        
        FWE_map, threshold05 = threshold_stats_img(
            z_map, 
            alpha=0.05,
            height_control='bonferroni',
            two_sided=True,
            cluster_threshold=0
        )
        
        # Get peaks   
        peaks = get_clusters_table(FWE_map, stat_threshold=threshold05)
        
        # If there is any peak then save the map and generate report
        if len(peaks) != 0:
            print('Creating output for', contrast_pair)
            Fname = os.path.join(sl_path, contrast_pair + '_FWE05v0.nii.gz')
            FWE_map.to_filename(Fname)
            # Generate and save also atlasreader output
            create_output(
                Fname, 
                cluster_extent=0, 
                voxel_thresh=threshold05,
                direction='pos',
                outdir=os.path.join(sl_path, 'atlasreader', contrast_pair)
            )
        else:
            print('No significant voxels at FWE05 for', contrast_pair)
print('done')
